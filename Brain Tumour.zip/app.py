from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np
import io

app = Flask(__name__)
CORS(app)

# Load the model (.h5 file)
model = load_model("models/cnn-parameters-improvement-01-0.58.keras")  # <- replace with your filename

# Ensure image is resized to match model's input shape
def preprocess_image(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    img = img.resize((240, 240))  # <- match the input size your model expects
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

@app.route("/predict", methods=["POST"])
def predict():
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    file = request.files['file']
    image_bytes = file.read()
    image = preprocess_image(image_bytes)

    prediction = model.predict(image)[0][0]  # Adjust if output is different

    if prediction > 0.5:
        result = "Tumor Detected"
    else:
        result = "No Tumor Detected"

    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(debug=True)
